﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trang_QL_Sinh_Vien
{
    public partial class Form1 : Form
    {
        List<SinhVien> danhSach = new List<SinhVien>();
        List<LopHoc> danhSachLop = new List<LopHoc>();
        int index;
        int indexLop = -1;
        bool suppressTabLoad = false; // used to avoid automatic reload when programmatically switching tabs
        public Form1()
        {
            InitializeComponent();
            this.button1.Click += Button1_Click;
            this.Load += Form1_Load;
            this.button2.Click += Button2_Click; // Sửa
            this.button3.Click += Button3_Click; // Xóa
            this.button4.Click += Button4_Click; // Làm mới
            this.button5.Click += Button5_Click; // Tìm
            this.dataGridView1.CellClick += DataGridView1_CellClick;

            // tabPage2 controls
            this.button10.Click += Button10_Click; // Thêm lớp
            this.button9.Click += Button9_Click; // Sửa lớp
            this.button8.Click += Button8_Click; // Xóa lớp
            this.button7.Click += Button7_Click; // Làm mới lớp
            this.button6.Click += Button6_Click; // Tìm lớp
            this.dataGridView2.CellClick += DataGridView2_CellClick;
            this.button11.Click += Button11_Click; // Xem danh sách SV của lớp
            this.tabControl1.SelectedIndexChanged += TabControl1_SelectedIndexChanged;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                LoadStudents();
                LoadClasses();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể kết nối tới cơ sở dữ liệu: " + ex.Message);
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void LoadStudents()
        {
            danhSach = DataAccess.GetAllStudents();
            dataGridView1.Rows.Clear();
            foreach (var sv in danhSach)
            {
                dataGridView1.Rows.Add(sv.MSV, sv.Class, sv.Name, sv.GioiTinh, sv.NgaySinh.ToShortDateString());
            }
            // populate gender combo if empty
            if (comboBox1.Items.Count == 0)
            {
                comboBox1.Items.AddRange(new[] { "Nam", "Nữ", "Khác" });
            }
        }

        private void LoadClasses()
        {
            danhSachLop = DataAccess.GetAllClasses();
            dataGridView2.Rows.Clear();
            foreach (var l in danhSachLop)
            {
                dataGridView2.Rows.Add(l.Id, l.MaLop, l.TenLop, l.GhiChu);
            }
            // Provide autocomplete suggestions for class input in student tab
            try
            {
                var auto = new AutoCompleteStringCollection();
                auto.AddRange(danhSachLop.Select(x => x.MaLop).Where(s => !string.IsNullOrEmpty(s)).ToArray());
                textBox3.AutoCompleteCustomSource = auto;
                textBox3.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                textBox3.AutoCompleteSource = AutoCompleteSource.CustomSource;
            }
            catch
            {
                // ignore UI autocomplete failures
            }
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            index = e.RowIndex;
            var row = dataGridView1.Rows[e.RowIndex];
            txtMSV1.Text = row.Cells[0].Value?.ToString() ?? string.Empty;
            textBox3.Text = row.Cells[1].Value?.ToString() ?? string.Empty;
            txtName1.Text = row.Cells[2].Value?.ToString() ?? string.Empty;
            comboBox1.Text = row.Cells[3].Value?.ToString() ?? string.Empty;
            DateTime dt;
            if (DateTime.TryParse(row.Cells[4].Value?.ToString(), out dt))
                dateTimePicker1.Value = dt;
        }

        private void DataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            indexLop = e.RowIndex;
            var row = dataGridView2.Rows[e.RowIndex];
            // columns: Id, MaLop, TenLop, GhiChu
            textBox6.Text = row.Cells[0].Value?.ToString() ?? string.Empty; // Ma ID
            textBox5.Text = row.Cells[1].Value?.ToString() ?? string.Empty; // Ma Lop
            textBox7.Text = row.Cells[2].Value?.ToString() ?? string.Empty; // Ten Lop
            textBox2.Text = row.Cells[3].Value?.ToString() ?? string.Empty; // Ghi Chu
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            // Cập nhật
            var msv = txtMSV1.Text.Trim();
            if (string.IsNullOrEmpty(msv))
            {
                MessageBox.Show("Vui lòng chọn hoặc nhập MSV để sửa.");
                return;
            }
            var sv = new SinhVien
            {
                MSV = msv,
                Name = txtName1.Text.Trim(),
                Class = textBox3.Text.Trim(),
                GioiTinh = comboBox1.Text,
                NgaySinh = dateTimePicker1.Value.Date
            };
            try
            {
                DataAccess.UpdateStudent(sv);
                LoadStudents();
                MessageBox.Show("Cập nhật sinh viên thành công.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật: " + ex.Message);
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            var msv = txtMSV1.Text.Trim();
            if (string.IsNullOrEmpty(msv))
            {
                MessageBox.Show("Vui lòng chọn sinh viên để xóa.");
                return;
            }
            var confirm = MessageBox.Show($"Xóa sinh viên {msv}?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;
            try
            {
                DataAccess.DeleteStudent(msv);
                LoadStudents();
                ClearInputs();
                MessageBox.Show("Đã xóa.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa: " + ex.Message);
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            ClearInputs();
        }

        private void ClearInputs()
        {
            txtMSV1.Text = string.Empty;
            txtName1.Text = string.Empty;
            textBox3.Text = string.Empty;
            comboBox1.Text = string.Empty;
            dateTimePicker1.Value = DateTime.Today;
            dataGridView1.ClearSelection();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            var q = textBox4.Text.Trim();
            if (string.IsNullOrEmpty(q))
            {
                LoadStudents();
                return;
            }
            var filtered = danhSach.Where(s =>
                (!string.IsNullOrEmpty(s.MSV) && s.MSV.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
                || (!string.IsNullOrEmpty(s.Name) && s.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
                || (!string.IsNullOrEmpty(s.Class) && s.Class.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
            ).ToList();
            dataGridView1.Rows.Clear();
            foreach (var sv in filtered)
            {
                dataGridView1.Rows.Add(sv.MSV, sv.Class, sv.Name, sv.GioiTinh, sv.NgaySinh.ToShortDateString());
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            // Validate required fields
            var msvVal = txtMSV1.Text.Trim();
            if (string.IsNullOrEmpty(msvVal))
            {
                MessageBox.Show("Vui lòng nhập MSV.");
                return;
            }
            var nameVal = txtName1.Text.Trim();
            if (string.IsNullOrEmpty(nameVal))
            {
                MessageBox.Show("Vui lòng nhập Họ và tên.");
                return;
            }

            var sv = new SinhVien
            {
                MSV = msvVal,
                Name = nameVal,
                Class = textBox3.Text.Trim(),
                GioiTinh = comboBox1.Text,
                NgaySinh = dateTimePicker1.Value.Date
            };
            try
            {
                DataAccess.InsertStudent(sv);
                LoadStudents();
                MessageBox.Show("Thêm sinh viên thành công.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm sinh viên: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        // --- Class (LopHoc) handlers ---
        private void Button10_Click(object sender, EventArgs e)
        {
            // Thêm lớp
            var l = new LopHoc
            {
                MaLop = textBox5.Text.Trim(),
                TenLop = textBox7.Text.Trim(),
                GhiChu = textBox2.Text.Trim()
            };
            try
            {
                DataAccess.InsertClass(l);
                LoadClasses();
                MessageBox.Show("Thêm lớp thành công.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm lớp: " + ex.Message);
            }
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            // Sửa lớp
            if (indexLop < 0 || indexLop >= danhSachLop.Count)
            {
                MessageBox.Show("Vui lòng chọn lớp để sửa.");
                return;
            }
            var l = new LopHoc
            {
                Id = int.TryParse(textBox6.Text, out int idVal) ? idVal : danhSachLop[indexLop].Id,
                MaLop = textBox5.Text.Trim(),
                TenLop = textBox7.Text.Trim(),
                GhiChu = textBox2.Text.Trim()
            };
            try
            {
                DataAccess.UpdateClass(l);
                LoadClasses();
                MessageBox.Show("Cập nhật lớp thành công.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi cập nhật lớp: " + ex.Message);
            }
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            // Xóa lớp
            if (indexLop < 0 || indexLop >= danhSachLop.Count)
            {
                MessageBox.Show("Vui lòng chọn lớp để xóa.");
                return;
            }
            var id = danhSachLop[indexLop].Id;
            var confirm = MessageBox.Show($"Xóa lớp {danhSachLop[indexLop].MaLop}?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;
            try
            {
                DataAccess.DeleteClass(id);
                LoadClasses();
                ClearClassInputs();
                MessageBox.Show("Đã xóa lớp.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa lớp: " + ex.Message);
            }
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            ClearClassInputs();
        }

        private void ClearClassInputs()
        {
            textBox6.Text = string.Empty;
            textBox5.Text = string.Empty;
            textBox7.Text = string.Empty;
            textBox2.Text = string.Empty;
            dataGridView2.ClearSelection();
            indexLop = -1;
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            var q = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(q))
            {
                LoadClasses();
                return;
            }
            var filtered = danhSachLop.Where(l =>
                (!string.IsNullOrEmpty(l.MaLop) && l.MaLop.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
                || (!string.IsNullOrEmpty(l.TenLop) && l.TenLop.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
            ).ToList();
            dataGridView2.Rows.Clear();
            foreach (var l in filtered)
            {
                dataGridView2.Rows.Add(l.Id, l.MaLop, l.TenLop, l.GhiChu);
            }
        }

        private void Button11_Click(object sender, EventArgs e)
        {
            // Xem danh sách sinh viên theo lớp đang chọn
            var maLop = textBox5.Text.Trim();
            if (string.IsNullOrEmpty(maLop))
            {
                MessageBox.Show("Vui lòng chọn hoặc nhập Ma Lop để xem danh sách sinh viên.");
                return;
            }
            try
            {
                var svs = DataAccess.GetStudentsByClass(maLop);
                // Show in student grid (tab1)
                dataGridView1.Rows.Clear();
                foreach (var sv in svs)
                {
                    dataGridView1.Rows.Add(sv.MSV, sv.Class, sv.Name, sv.GioiTinh, sv.NgaySinh.ToShortDateString());
                }
                // switch to tab1 but avoid automatic reload of full students list
                suppressTabLoad = true;
                tabControl1.SelectedTab = tabPage1;
                suppressTabLoad = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi lấy danh sách sinh viên: " + ex.Message);
            }
        }

        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // If we switched programmatically to show filtered students, don't reload.
            if (tabControl1.SelectedTab == tabPage1)
            {
                if (!suppressTabLoad)
                    LoadStudents();
            }
            else if (tabControl1.SelectedTab == tabPage2)
            {
                LoadClasses();
            }
        }
    }
}
