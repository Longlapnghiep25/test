﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trang_QL_Sinh_Vien
{
    public class SinhVien
    {
        public string MSV { get; set; }
        public string Name { get; set; }
        public string GioiTinh { get; set; }
        public DateTime NgaySinh { get; set; }
        public string Class { get; set; }
    }

    public class LopHoc
    {
        public int Id { get; set; }
        public string MaLop { get; set; }
        public string TenLop { get; set; }
        public string GhiChu { get; set; }
    }
}
