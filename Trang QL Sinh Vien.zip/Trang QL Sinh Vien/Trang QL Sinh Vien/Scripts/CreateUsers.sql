-- Create Users table and a sample account
USE QuanLySV;
GO

IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL
    DROP TABLE dbo.Users;
GO

CREATE TABLE dbo.Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(200) NOT NULL,
    FullName NVARCHAR(200) NULL
);
GO

-- Sample users (username: admin, password: admin)
INSERT INTO dbo.Users (Username, Password, FullName) VALUES ('admin','admin','Administrator');
INSERT INTO dbo.Users (Username, Password, FullName) VALUES ('user1','password1','Người dùng 1');
GO
