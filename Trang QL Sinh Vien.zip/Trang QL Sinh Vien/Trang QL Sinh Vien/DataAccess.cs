using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Trang_QL_Sinh_Vien
{
    public static class DataAccess
    {
        // If you prefer using App.config, replace this constant with ConfigurationManager reading.
        private const string DefaultConnectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=QuanLySV;Integrated Security=True;";
        private static string GetConnectionString()
        {
            // Use the constant default connection string. App.config may be present in the project,
            // but referencing ConfigurationManager can cause build issues in certain SDK/project setups.
            // Keeping a single constant ensures the project builds and runs as expected.
            return DefaultConnectionString;
        }

        // Students
        public static List<SinhVien> GetAllStudents()
        {
            var list = new List<SinhVien>();
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("SELECT MSV, Name, GioiTinh, NgaySinh, Class FROM Students", conn))
            {
                conn.Open();
                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        var sv = new SinhVien
                        {
                            MSV = rd["MSV"].ToString(),
                            Name = rd["Name"].ToString(),
                            GioiTinh = rd["GioiTinh"].ToString(),
                            NgaySinh = rd.IsDBNull(rd.GetOrdinal("NgaySinh")) ? DateTime.MinValue : rd.GetDateTime(rd.GetOrdinal("NgaySinh")),
                            Class = rd["Class"].ToString()
                        };
                        list.Add(sv);
                    }
                }
            }
            return list;
        }

        public static void InsertStudent(SinhVien sv)
        {
            // ensure class exists (to avoid FK violation) - if class provided but not present, create placeholder
            if (!string.IsNullOrEmpty(sv.Class) && !ClassExists(sv.Class))
            {
                InsertClass(new LopHoc { MaLop = sv.Class, TenLop = sv.Class, GhiChu = "(Tự tạo)" });
            }
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("INSERT INTO Students (MSV, Name, GioiTinh, NgaySinh, Class) VALUES (@msv,@name,@gt,@ns,@lop)", conn))
            {
                cmd.Parameters.AddWithValue("@msv", sv.MSV ?? string.Empty);
                cmd.Parameters.AddWithValue("@name", sv.Name ?? string.Empty);
                cmd.Parameters.AddWithValue("@gt", sv.GioiTinh ?? string.Empty);
                cmd.Parameters.AddWithValue("@ns", sv.NgaySinh == DateTime.MinValue ? (object)DBNull.Value : sv.NgaySinh);
                // If Class is empty or null, pass DB NULL so the FK check isn't triggered with an empty string
                cmd.Parameters.AddWithValue("@lop", string.IsNullOrEmpty(sv.Class) ? (object)DBNull.Value : sv.Class);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void UpdateStudent(SinhVien sv)
        {
            // ensure class exists (to avoid FK violation)
            if (!string.IsNullOrEmpty(sv.Class) && !ClassExists(sv.Class))
            {
                InsertClass(new LopHoc { MaLop = sv.Class, TenLop = sv.Class, GhiChu = "(Tự tạo)" });
            }
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("UPDATE Students SET Name=@name, GioiTinh=@gt, NgaySinh=@ns, Class=@lop WHERE MSV=@msv", conn))
            {
                cmd.Parameters.AddWithValue("@msv", sv.MSV ?? string.Empty);
                cmd.Parameters.AddWithValue("@name", sv.Name ?? string.Empty);
                cmd.Parameters.AddWithValue("@gt", sv.GioiTinh ?? string.Empty);
                cmd.Parameters.AddWithValue("@ns", sv.NgaySinh == DateTime.MinValue ? (object)DBNull.Value : sv.NgaySinh);
                // If Class is empty or null, pass DB NULL so the FK check isn't triggered with an empty string
                cmd.Parameters.AddWithValue("@lop", string.IsNullOrEmpty(sv.Class) ? (object)DBNull.Value : sv.Class);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static bool ClassExists(string maLop)
        {
            if (string.IsNullOrEmpty(maLop)) return false;
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("SELECT COUNT(1) FROM Classes WHERE MaLop=@ma", conn))
            {
                cmd.Parameters.AddWithValue("@ma", maLop);
                conn.Open();
                var res = cmd.ExecuteScalar();
                if (res != null && int.TryParse(res.ToString(), out int c)) return c > 0;
                return false;
            }
        }

        public static void DeleteStudent(string msv)
        {
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("DELETE FROM Students WHERE MSV=@msv", conn))
            {
                cmd.Parameters.AddWithValue("@msv", msv ?? string.Empty);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // Classes
        public static List<LopHoc> GetAllClasses()
        {
            var list = new List<LopHoc>();
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("SELECT Id, MaLop, TenLop, GhiChu FROM Classes", conn))
            {
                conn.Open();
                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        var l = new LopHoc
                        {
                            Id = rd.GetInt32(rd.GetOrdinal("Id")),
                            MaLop = rd["MaLop"].ToString(),
                            TenLop = rd["TenLop"].ToString(),
                            GhiChu = rd["GhiChu"].ToString()
                        };
                        list.Add(l);
                    }
                }
            }
            return list;
        }

        public static void InsertClass(LopHoc l)
        {
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("INSERT INTO Classes (MaLop, TenLop, GhiChu) VALUES (@ma,@ten,@ghi)", conn))
            {
                cmd.Parameters.AddWithValue("@ma", l.MaLop ?? string.Empty);
                cmd.Parameters.AddWithValue("@ten", l.TenLop ?? string.Empty);
                cmd.Parameters.AddWithValue("@ghi", l.GhiChu ?? string.Empty);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void UpdateClass(LopHoc l)
        {
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("UPDATE Classes SET MaLop=@ma, TenLop=@ten, GhiChu=@ghi WHERE Id=@id", conn))
            {
                cmd.Parameters.AddWithValue("@id", l.Id);
                cmd.Parameters.AddWithValue("@ma", l.MaLop ?? string.Empty);
                cmd.Parameters.AddWithValue("@ten", l.TenLop ?? string.Empty);
                cmd.Parameters.AddWithValue("@ghi", l.GhiChu ?? string.Empty);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void DeleteClass(int id)
        {
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("DELETE FROM Classes WHERE Id=@id", conn))
            {
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static List<SinhVien> GetStudentsByClass(string maLop)
        {
            var list = new List<SinhVien>();
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("SELECT MSV, Name, GioiTinh, NgaySinh, Class FROM Students WHERE Class=@lop", conn))
            {
                cmd.Parameters.AddWithValue("@lop", maLop ?? string.Empty);
                conn.Open();
                using (var rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        var sv = new SinhVien
                        {
                            MSV = rd["MSV"].ToString(),
                            Name = rd["Name"].ToString(),
                            GioiTinh = rd["GioiTinh"].ToString(),
                            NgaySinh = rd.IsDBNull(rd.GetOrdinal("NgaySinh")) ? DateTime.MinValue : rd.GetDateTime(rd.GetOrdinal("NgaySinh")),
                            Class = rd["Class"].ToString()
                        };
                        list.Add(sv);
                    }
                }
            }
            return list;
        }

        public static bool Authenticate(string username, string password)
        {
            // Simple authentication against a Users table (Username, Password)
            using (var conn = new SqlConnection(GetConnectionString()))
            using (var cmd = new SqlCommand("SELECT COUNT(1) FROM Users WHERE Username=@u AND Password=@p", conn))
            {
                cmd.Parameters.AddWithValue("@u", username);
                cmd.Parameters.AddWithValue("@p", password);
                conn.Open();
                var result = cmd.ExecuteScalar();
                if (result != null && int.TryParse(result.ToString(), out int count))
                {
                    return count > 0;
                }
                return false;
            }
        }
    }
}
